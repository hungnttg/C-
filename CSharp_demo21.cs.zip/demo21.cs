  using System;
  class HelloWorld {
    static void Main() {
      menu();
    }
    public static void menu()
    {
      Console.WriteLine("Moi ban chon chuc nang");
      Console.WriteLine("1. Giai PTB1");
      Console.WriteLine("2. Giai PTB2");
      Console.WriteLine("3. Nhap ngay thang");
      Console.WriteLine("4. So nguyen to");
      int answer = Convert.ToInt32(Console.ReadLine());
      if(answer==1)
      {
        giaiPTB1();
      }
      else if(answer==2)
      {
        giaiPTB2();
      }
      else if(answer==3)
      {
        nhapNgayThang();
      }
       else if(answer==4)
      {
        soNguyenTo();
      }
    }
    public static void soNguyenTo()
    {
      Console.WriteLine("Moi ban nhap vao 1 so");
      int so = Convert.ToInt32(Console.ReadLine());
      bool isSoNguyenTo = true;//gia su so nhap vao la so nguyen to
      for(int i=2;i<so-1;i++)//kiem tra xem neu no chia het cho 1 so khac=>k phai snt
      {
        if(so%i==0)//chia het cho i du 0
        {
          isSoNguyenTo=false;
        }
      }
      if(isSoNguyenTo==true)
      {
        Console.WriteLine(so+" la so nguyen to");
      }
      else
      {
          Console.WriteLine(so+" khong phai la so nguyen to");
      }
      menu();
    }
    public static void nhapNgayThang()
    {
      Console.WriteLine("Moi nhap ngay thang");
      DateTime d;
      try{ //thu lam 1 viec 
         d=Convert.ToDateTime(Console.ReadLine());//nhap vao ngay thang
         Console.WriteLine("Ngay thang vua nhap: "+d);
         Console.WriteLine("Tinh ngay trong thang");
        Console.WriteLine("Moi nhap nam");
        int year = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Moi nhap Thang");
        int month = Convert.ToInt32(Console.ReadLine());
        int soNgay = DateTime.DaysInMonth(year,month);//convert sang ngay thang
        Console.WriteLine("So ngay trong thang "+month+"/"+year+" la "+soNgay);
        Console.WriteLine("Ngay mai la: "+d.AddDays(1));//them 1 ngay
        Console.WriteLine("Ngay hom qua la: "+d.AddDays(-1));//tru di 1 ngay
        menu();
      }
      catch(Exception e)//neu xay ra loi, xu ly
      {
         Console.WriteLine(e.ToString());//in ra loi
      }
      //----
      
  
    }
    public static void giaiPTB2()
    {
      Console.WriteLine("Giai phuong trinh bac 2");
      Console.WriteLine("a=");
      int a = Convert.ToInt32(Console.ReadLine());//nhap bien a tu ban phim
      Console.WriteLine("b=");
      int b = Convert.ToInt32(Console.ReadLine());//nhap bien a tu ban phim
      Console.WriteLine("c=");
      int c = Convert.ToInt32(Console.ReadLine());
      float delta = b*b-4*a*c;
      if(a==0)
      {
        Console.WriteLine("Day la PT bac 1, ban nhap lai a,b");
        giaiPTB1();
      }
      else
      {
          if(delta<0)
          {
            Console.WriteLine("PT vo nghiem");
          }
          else if(delta==0)
          {
            Console.WriteLine("PT co nghiem kep x="+(-b/2*a));
          }
          else
          {
              float x1 = (float)(-b+Math.Sqrt(delta))/(2*a);
              float x2 = (float)(-b-Math.Sqrt(delta))/(2*a);
              Console.WriteLine("Co 2 nghiem x1="+x1+" va x2"+x2);
          }
      }
      menu();
    }
    public static void giaiPTB1()
    {
      Console.WriteLine("Giai phuong trinh bac 1");
      Console.WriteLine("a=");
      int a = Convert.ToInt32(Console.ReadLine());//nhap bien a tu ban phim
      Console.WriteLine("b=");
      int b = Convert.ToInt32(Console.ReadLine());//nhap bien a tu ban phim
      if(a==0)
      {
        if(b==0)
        {
          Console.WriteLine("PT co VSN");
        }
        else
        {
            Console.WriteLine("PT co Vo nghiem");
        }
      }
      else
      {
          Console.WriteLine("Nghiem cua phuong trinh x="+(-b/a));
      }
      menu();
    }
  }